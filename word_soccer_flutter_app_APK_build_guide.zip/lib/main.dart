import 'package:flutter/material.dart';

void main() {
  runApp(const WordSoccerApp());
}

class WordSoccerApp extends StatelessWidget {
  const WordSoccerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Word Soccer',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Word Soccer')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 16),
            const Text(
              '오늘의 10문제 ⚽',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: const [
                    Text('기본 등록 학생', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    SizedBox(height: 10),
                    Text('김경완', style: TextStyle(fontSize: 18)),
                    Text('김태인', style: TextStyle(fontSize: 18)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              '※ 이 ZIP은 Flutter SDK가 설치된 PC에서\n프로젝트 생성 후(main.dart 유지) APK로 빌드하는 형태입니다.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
