# Word Soccer (APK 빌드 방법)

이 ZIP에는 `lib/main.dart`와 `pubspec.yaml`이 들어 있습니다.
Flutter 프로젝트의 플랫폼 폴더(`android/`, `ios/` 등)는 **Flutter가 설치된 PC에서 자동 생성**하는 것이 가장 안전합니다.

## 1) 준비물
- Flutter SDK 설치
- Android Studio 설치(또는 Android SDK/Platform Tools 포함 환경)
- 터미널에서 `flutter --version`이 정상 출력되어야 합니다.

## 2) 프로젝트 생성(중요)
ZIP을 풀고, 폴더 안에서 아래 명령을 실행하세요.

```bash
# (권장) 새 프로젝트 폴더를 만들고 이동
mkdir word_soccer_app
cd word_soccer_app

# Flutter 프로젝트 생성
flutter create .

# ZIP에 있는 파일 덮어쓰기
# - lib/main.dart
# - pubspec.yaml
```

> ZIP을 `word_soccer_app` 폴더에 풀어두었다면,
> `flutter create .`만 실행해도 `android/` 등이 생성됩니다.
> (이미 `lib/main.dart`가 있어도 Flutter가 필요한 파일을 생성해 줍니다.)

## 3) 의존성 받기
```bash
flutter pub get
```

## 4) APK 빌드(릴리즈)
```bash
flutter build apk --release
```

## 5) APK 위치
빌드가 끝나면 아래 경로에 생성됩니다.

- android/app/build/outputs/flutter-apk/app-release.apk

## 6) 폰에 설치
- USB로 옮겨 설치하거나,
- adb 사용:
```bash
adb install -r android/app/build/outputs/flutter-apk/app-release.apk
```

## 참고(서명/스토어 배포)
Play 스토어 배포용 keystore/서명 설정은 별도 단계가 필요합니다.
